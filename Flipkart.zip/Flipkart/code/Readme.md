Preferred Operating Systems: MacOS / Windows, as a substantial number of dependencies are requisite.

To initiate the process, kindly execute the following commands in the command-line terminal:

1. Install essential dependencies by inputting the subsequent command:

   ```
   pip install -r requirements.txt
   ```

2. After the successful installation of dependencies, proceed by running the application using the ensuing command:

   ```
   python app.py
   ```

In the event that errors related to dependencies arise during the execution, it is recommended to undertake the following steps:

1. Thoroughly inspect the error messages presented.

2. If the error pertains to unmet dependencies, rectify the issue by manually installing the deficient packages. Execute the subsequent command for each deficient package:

   ```
   pip install <package_name>
   ```

It is advised to consult the documentation or respective sources for additional assistance if encountering challenges during the process.
